package hr.fer.zemris.optjava.dz5.part1;

import java.util.Random;

/**
 * Class implements random selection of parent.
 * 
 * @author Branko
 *
 * @param <T>
 */
public class RandomSelection<T extends SingleObjectiveSolution> {

	/**
	 * Method implements random selection of parent from group of solution
	 * @param group group of solution
	 * @return random soultion
	 */
	public T select(T[] group) {
		Random rand = new Random();
		return group[rand.nextInt(group.length)];
	}

}
