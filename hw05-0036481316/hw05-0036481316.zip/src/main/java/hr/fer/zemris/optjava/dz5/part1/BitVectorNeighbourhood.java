package hr.fer.zemris.optjava.dz5.part1;

import java.util.Random;
/**
 * Class implements {@linkplain INeighborhood} and calculates next neighbour.
 * 
 * @author Branko
 *
 */
public class BitVectorNeighbourhood implements INeighborhood<BitvectorSolution>{


	/**
	 * Private reference {@linkplain Random} 
	 */
	protected Random rand;
	
	/**
	 * Public constructor accepts desire settings
	 * 
	 * @param deltas desire neighbourhood range for every variable
	 */
	public BitVectorNeighbourhood() {
		rand = new Random();
	}
	
	@Override
	public BitvectorSolution randomNeighbor(BitvectorSolution t) {
		Random rand = new Random();
		boolean change = false;
		BitvectorSolution temp = t.duplicate();
		for(int i = 0,limit =temp.bits.length ; i<limit; i++){
			if(rand.nextDouble()<0.15){
				temp.bits[i]  =temp.bits[i]^true;
				change = true;
			}
		}
		if(!change){
			int index = rand.nextInt(temp.bits.length);
			temp.bits[index]= temp.bits[index]^true;
		}
		temp.updateFitness();
		return temp;
	}

}
