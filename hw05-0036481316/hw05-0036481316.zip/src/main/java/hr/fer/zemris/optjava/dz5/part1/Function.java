package hr.fer.zemris.optjava.dz5.part1;

/**
 * Class implements {@linkplain IFunction}. Function calculates fitness for
 * problem for maximise number of ones in byte vector.
 * 
 * @author Branko
 *
 */
public class Function implements IFunction {

	/**
	 * number of variables in function
	 */
	private int numberOfVariables;

	/**
	 * Public constructor accepts desire settings.
	 * 
	 * @param numberOfVariables
	 *            desire number of variables.
	 */
	public Function(int numberOfVariables) {
		this.numberOfVariables = numberOfVariables;
	}

	/**
	 * Public method which calculates number of ones in vector.
	 * 
	 * @param array
	 *            vector solution
	 * @return number of ones in vector
	 */
	public int numberOfOnes(boolean[] array) {
		int sum = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i]) {
				sum++;
			}
		}
		return sum;
	}

	@Override
	public double valueAt(boolean[] array) {

		double numOfOnes = (double) this.numberOfOnes(array);
		double numOfVariables = (double) this.numberOfVariables;

		if (numOfOnes <= 0.8 * numOfVariables) {
			return numOfOnes / numOfVariables;
		} else if ((numOfOnes <= 0.9 * numOfVariables) && (numOfOnes > 0.8 * numOfVariables)) {
			return 0.8;
		}
		return (2 * numOfOnes / numOfVariables) - 1;
	}

	@Override
	public int numberOfVariables() {

		return numberOfVariables;
	}
}