package hr.fer.zemris.optjava.dz5.part1;

/**
 * Class that represent crossover of two chromosomes and generate one child.
 * 
 * @author Branko
 *
 */
public class CrossOverBit {

	/**
	 * Method implements crossover of two parents and generate one child
	 * 
	 * @param parent1
	 *            first parent
	 * @param parent2
	 *            second parent
	 * @return child
	 */
	public BitvectorSolution cross(BitvectorSolution parent1, BitvectorSolution parent2) {
		BitvectorSolution child = new BitvectorSolution(parent1.bits.length, null, null,
				new Function(parent1.bits.length), null);
		int size = parent1.bits.length;
		int part = parent1.bits.length / 3;
		for (int i = 0; i < part; i++) {
			child.bits[i] = parent1.bits[i];
		}
		for (int i = part; i < 2 * part; i++) {
			child.bits[i] = parent1.bits[i];
		}
		for (int i = 2 * part; i < size; i++) {
			child.bits[i] = parent1.bits[i];
		}
		child.updateFitness();
		return child;
	}
}
