package hr.fer.zemris.optjava.dz5.part2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;


import hr.fer.zemris.optjava.dz5.part1.Tournament;

/**
 * Class implements self-adaptive segregative genetic algorithm with simulated annealing aspects.
 * Program uses arguments from command line. First argument must be path to file,
 *  second argument is size of population, third is number of subpopulations.
 *  
 * @author Branko
 *
 */
public class GeneticAlgorithm {

	/**
	 * Number of units in subpopulation
	 */
	private int numberOfSubpopulation;
	/**
	 * size of population
	 */
	private int populationSize;
	/**
	 * hyper parameter for increasing comparison factor
	 */
	private double alpha;
	/**
	 * Maximum selection pressure
	 */
	private double MaxSelPress;
	/**
	 * Comparison factor
	 */
	private double compFact;
	/**
	 * dimension of solution
	 */
	private int n;
	/**
	 * size of k-tournament
	 */
	private int nTor;
	/**
	 * Private reference {@linkplain Function}
	 */
	private Function function;
	
	public static void main(String[] args) {
		if(args.length != 3){
			errorMsg();
		}
		Path path = Paths.get(args[0]);
		if (!Files.exists(path)) {
			errorMsg();
		}
		
		int sizeOfPopulation =0;
		int numberOfSubpop = 0;
		try{
			sizeOfPopulation = Integer.parseInt(args[1]);
			numberOfSubpop = Integer.parseInt(args[2]);
		}catch(NumberFormatException ex){
			errorMsg();
		}
		HashMap<Integer, ArrayList<Double>> materials = new HashMap<>();
		HashMap<Integer, ArrayList<Double>> distances = new HashMap<>();
		int n=0, number1 =0, number2 =0;
		
		try (Stream<String> lines = Files.lines(path)) {
			Iterator<String> iter = lines.iterator();
			int count =0;
			ArrayList<Double> numbers = new ArrayList<>();

			while (iter.hasNext()) {
				String line = iter.next();
				if(line.trim().isEmpty()){
					count++;
					continue;
				}
				line = line.trim();
				if(count == 0){
					n = Integer.parseInt(line);
				}else{
					String[] parts = line.split("\\s+");
					for(int i =0; i< parts.length; i++){
						numbers.add(Double.parseDouble(parts[i]));
					}
					if(numbers.size() != n){
						continue;
					}
					if(count == 1){
						distances.put(number1++, numbers);
						numbers = new ArrayList<>();

					}else if(count == 2){
						materials.put(number2++, numbers);
						numbers = new ArrayList<>();
					}
				}
				
				
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Function func = new Function(materials, distances, n);
		GeneticAlgorithm algh  = new GeneticAlgorithm(sizeOfPopulation, numberOfSubpop, n, func);
		algh.run();
	}
	
	/**
	 * Method which display error message to user
	 */
	private static void errorMsg() {
		System.out.println("Dear user, first argument must be path to file,"
				+ " second argument is size of population, third is number of subpopulations");
		
		System.exit(0);
		
	}

	/**
	 * Public constructor accepts desire settings.
	 * 
	 * @param n dimension of solution
	 */
	public GeneticAlgorithm(int populationSize, int numberOfSubpopulation,int n, Function function) {
		this.numberOfSubpopulation = numberOfSubpopulation;
		this.populationSize = populationSize;
		this.alpha = 0.99;
		this.MaxSelPress = 6;
		nTor = (int)(n+1/2);
		this.n = n;
		compFact = 1;
		this.function = function;
	}
	
	/**
	 * Method which executes algorithm
	 */
	public void run(){
		ArrayList<Factories> population = new ArrayList<>();
		for(int i =0; i< populationSize; i++){
			population.add(new Factories(n, this.function));
		}
		ArrayList<Factories> reunification = new ArrayList<>();
		
		int factor =(int) ((double)populationSize/numberOfSubpopulation);
		int lower = 0, upper =0;
		
		do{
		
		for(int i = 0; i< numberOfSubpopulation; i++){
			
			lower = i*numberOfSubpopulation;
			upper = (i+1)*numberOfSubpopulation;
			if(i==(numberOfSubpopulation-1)) upper = populationSize;
			ArrayList<Factories> subPop = new ArrayList<>();
			
			for(int j = lower ; j < upper; j++){
				subPop.add(population.get(j));
			}
			if(subPop.size() == 0){
				continue;
			}
			population.addAll(village(subPop));
		}
		numberOfSubpopulation--;
		}while(numberOfSubpopulation!=1);
		
		Collections.sort(population, new Comparator<Factories>() {
			@Override
			public int compare(Factories o1, Factories o2) {
				if (o1.fitness > o2.fitness) {
					return 1;
				} else if (o1.fitness == o2.fitness) {
					return 0;
				}
				return -1;

			}
		});
		Factories best = population.get(0);
		System.out.println("Final result "+best.fitness+" "+best.toString());
 	}
	
	/**
	 * Method which evolves subpopulation 
	 * @param myVillage subpopulation
	 * @return evolved subpopulation
	 */
	private ArrayList<Factories> village(ArrayList<Factories> myVillage){
		Tournament<Factories> select = new Tournament<>(nTor);
		Mutation mutation = new Mutation();
		Crossover crossover = new Crossover();
		
		Random rand = new Random();
		int tries = 0;
		double effort = 0;
		double comFactor = compFact;
		ArrayList<Factories> newPopulation = new ArrayList<>();
		ArrayList<Factories> pool = new ArrayList<>();


		do {
			ArrayList<Factories> nTor1 = new ArrayList<>();
			for (int i = 0; i < nTor; i++) {
				nTor1.add(myVillage.get(rand.nextInt(myVillage.size())));
			}
			Factories parent1 = select
					.select(Arrays.copyOf(nTor1.toArray(), nTor1.size(), Factories[].class));
			ArrayList<Factories> nTor2 = new ArrayList<>();
			for (int i = 0; i < nTor; i++) {
				nTor2.add(myVillage.get(rand.nextInt(myVillage.size())));
			}
			Factories parent2 = select
					.select(Arrays.copyOf(nTor2.toArray(), nTor2.size(), Factories[].class));

			Factories child = crossover.cross(parent1, parent2);
			child = mutation.mutation(child);
			child.updateFitness();

			if (child.fitness <= (Math.min(parent1.fitness, parent2.fitness)
					+ (1 - comFactor) * Math.abs(parent1.fitness - parent2.fitness))) {
				if(!newPopulation.contains(child)){
					newPopulation.add(child);

				}
			} else {
				tries++;
				pool.add(child);
			}

			comFactor *= alpha;
			
			
			effort = (newPopulation.size() + tries) / myVillage.size();
			
			if (newPopulation.size() == myVillage.size()) {
				myVillage = new ArrayList<>(newPopulation);
				newPopulation = new ArrayList<Factories>();
				
				tries = 0;
				effort = 0;
				comFactor = compFact;

				Collections.sort(myVillage, new Comparator<Factories>() {
					@Override
					public int compare(Factories o1, Factories o2) {
						if (o1.fitness > o2.fitness) {
							return 1;
						} else if (o1.fitness == o2.fitness) {
							return 0;
						}
						return -1;

					}
				});
				
				Factories best = myVillage.get(0);
				System.out.println("The best in new population " + best.fitness + " " + best.toString());

				continue;
			}
			
		

		
		}while (effort <= MaxSelPress);
		Collections.sort(pool, new Comparator<Factories>() {
			@Override
			public int compare(Factories o1, Factories o2) {
				if (o1.fitness > o2.fitness) {
					return 1;
				} else if (o1.fitness == o2.fitness) {
					return 0;
				}
				return -1;

			}
		});
		for(int i = 0, size = myVillage.size() -newPopulation.size(); i<size ; i++){
			newPopulation.add(pool.get(i));
		}
		return newPopulation;
	}
	
	
}
