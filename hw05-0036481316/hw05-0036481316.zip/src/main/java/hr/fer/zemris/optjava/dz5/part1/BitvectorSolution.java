package hr.fer.zemris.optjava.dz5.part1;

import java.util.Arrays;
import java.util.Random;
/**
 *  * Class inherent {@linkplain SingleObjectiveSolution}. Class represent solution
 * expressed in bits
 * 
 * @author Branko
 *
 */
public class BitvectorSolution extends SingleObjectiveSolution{

	/**
	 * values of bits
	 */
	public boolean[] bits;
	
	/**
	 * Public constructor accepts desire settings
	 * 
	 * @param size
	 *            size of solution
	 * @param decoder
	 *            reference to {@linkplain IDecoder}
	 * @param neighborhood
	 *            reference to {@linkplain INeighborhood}
	 * @param function
	 *            reference to {@linkplain IFunction}
	 * @param algorithm
	 *            reference to {@linkplain IOptAlgorithm}
	 */
	public BitvectorSolution(int size,IDecoder decoder, INeighborhood neighborhood, IFunction function,
			IOptAlgorithm algorithm) {
		super(decoder, neighborhood, function, algorithm);
		this.bits =new boolean[size];
		this.randomize(new Random());
		this.value = function.valueAt(this.bits);
		this.fitness = this.value;

	}
	
	/**
	 * Public method which returns new variable like this
	 * 
	 * @return new variable like this
	 */
	public BitvectorSolution newLikeThis(){
		BitvectorSolution temp = new BitvectorSolution(bits.length, decoder, neighborhood, function, algorithm);
		temp.bits = Arrays.copyOf(bits, bits.length);
		temp.fitness = this.fitness;
		temp.value = this.value;
		return temp;
				
	}
	
	@Override
	public boolean equals(Object obj) {
		BitvectorSolution vec=null;
		if(obj instanceof BitvectorSolution){
			vec = (BitvectorSolution)obj;
		}
		return Arrays.equals(this.bits, vec.bits);
	}
	
	/**
	 * Public method which returns duplicate of this
	 * 
	 * @return duplicate
	 */
	public BitvectorSolution duplicate(){
		BitvectorSolution temp = new BitvectorSolution(bits.length, decoder, neighborhood, function, algorithm);
		temp.bits = Arrays.copyOf(bits, bits.length);
		temp.fitness = this.fitness;
		temp.value = this.value;
		return temp;
	}
	
	/**
	 * Public function which sets random {@linkplain BitvectorSolution#bits}
	 * 
	 * @param rand
	 *            random seed and instance of {@linkplain Random}

	 */
	public void randomize(Random rand){
			 for(int i = 0, size = bits.length; i<size; i++){
				 if(rand.nextDouble()<=0.5){
					 bits[i]=true;
				 }else{
					 bits[i]=false;
				 }
			 }
		
	}
	
	/**
	 * Public method for calculating fitness
	 */
	public void updateFitness(){
		fitness = function.valueAt(this.bits);
		this.value = fitness;
		if(Double.isNaN(fitness) || Double.isInfinite(fitness)){
			fitness = 999999999;
		}
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i< bits.length; i++){
			if(bits[i]){
				sb.append("1");
			}else{
				sb.append("0");
			}
		}
		
		return sb.toString();
	}
 }
