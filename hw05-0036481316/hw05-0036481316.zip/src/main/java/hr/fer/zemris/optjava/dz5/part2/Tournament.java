package hr.fer.zemris.optjava.dz5.part2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
/**
 * Class implements {@linkplain Selection}.Tournament selection is 
 * a method of selecting an individual from a population of individuals in a genetic algorithm.
 * The winner of each tournament (the one with the best fitness) is selected for crossover.
 * @author Branko
 *
 */
public class Tournament<T extends SingleObjectiveSolution>{
	/**
	 * Number of units that participate in tournament
	 */
	private int n;
	
	/**
	 * Public constructor that accepts desire settings.
	 * 
	 * @param n desire number of units that participate in tournament
	 */
	public Tournament(int n) {
		this.n = n;
	}

	/**
	 * Public method which implements k-tournament selection
	 * 
	 * @param group group of solution
	 * @return the best solution from group
	 */
	public T select(T[] group) {
		
		Collections.sort(Arrays.asList(group), new Comparator<T>() {
    	    @Override
    	    public int compare(T o1, T o2) {
    	        if(o1.fitness > o2.fitness){
    	        	return 1;
    	        	}
    	        else if(o1.fitness == o2.fitness){
    	        	return 0;
    	        	}
    	        return -1;
    	        	
    	        
    	    }
    	});
		return group[0];
	}
}
