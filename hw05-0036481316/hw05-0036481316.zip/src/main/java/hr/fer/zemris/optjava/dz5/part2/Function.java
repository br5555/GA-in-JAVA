package hr.fer.zemris.optjava.dz5.part2;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class represent function which evaluates quality of factories layout
 * 
 * @author Branko
 *
 */
public class Function {
	/**
	 * Map stores amount of material transfer between to factories
	 */
	public HashMap<Integer, ArrayList<Double>> materials = new HashMap<>();
	/**
	 * Map stores distance between two factories
	 */
	public HashMap<Integer, ArrayList<Double>> distances = new HashMap<>();

	/**
	 * Public constructor which accepts desire settings
	 * 
	 * @param materials
	 *            map of materials
	 * @param distances
	 *            map of distance
	 * @param n
	 *            number of factories
	 */
	public Function(HashMap<Integer, ArrayList<Double>> materials, HashMap<Integer, ArrayList<Double>> distances,
			int n) {
		super();
		this.materials = materials;
		this.distances = distances;
	}

	/**
	 * Function evaluated quality of solution
	 * 
	 * @param fact
	 *            {@linkplain Factories}
	 * @return fitness of {@linkplain Factories}
	 */
	public double valueAt(Factories fact) {
		double sum = 0;
		for (int i = 0, size = (fact.solution.size()); i < size; i++) {
			
			ArrayList<Double> material = materials.get(fact.solution.get(i));
			ArrayList<Double> distance = distances.get(i);
			
			for (int j = 0, size1 = (fact.solution.size()); j < size1; j++) {
				
				sum += material.get(fact.solution.get(j)) * distance.get(j);
				
			}
		}
		return sum;
	}

}
