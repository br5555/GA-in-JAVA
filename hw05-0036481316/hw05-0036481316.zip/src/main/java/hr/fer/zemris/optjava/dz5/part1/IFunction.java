package hr.fer.zemris.optjava.dz5.part1;


/**
 * Interface that represent function and has generalisation method of every function.
 * 
 * @author Branko
 *
 */
public interface IFunction {

	/**
	 * Public method which calculates value of function at desire point.
	 * 
	 * @param array desire point
	 * @return value of function at desire point
	 */
	double valueAt(boolean[] array);

	int numberOfVariables();
	
	int numberOfOnes(boolean[] array);
}
