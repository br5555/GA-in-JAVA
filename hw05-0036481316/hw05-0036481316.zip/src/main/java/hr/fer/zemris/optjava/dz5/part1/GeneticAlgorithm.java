package hr.fer.zemris.optjava.dz5.part1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

/**
 * Class implements Relevant Alleles Preserving GA. Program accepts arguments
 * form command line argument is size of binary vector.
 * 
 * @author Branko
 *
 */
public class GeneticAlgorithm {

	/**
	 * Maximal size of population
	 */
	private int maxPopoluationSize;
	/**
	 * Minimal size of population
	 */
	private int minPopulationSize;
	/**
	 * Comparison factor
	 */
	private double comFactor;
	/**
	 * hyper parameter for increasing comparison factor
	 */
	private double alpha;
	/**
	 * maximal effort put for generating new population
	 */
	private double maxEffort;
	/**
	 * size of first population
	 */
	private int startPopulationSize;
	/**
	 * dimension of solution vector
	 */
	private int n;
	/**
	 * size of k-tournament
	 */
	private int nTor;

	/**
	 * Public constructor accepts desire settings.
	 * 
	 * @param n
	 *            desire size of solution vector
	 */
	public GeneticAlgorithm(int n) {
		this.maxPopoluationSize = 10 * n;
		this.minPopulationSize = n;
		this.comFactor = 1;
		this.alpha = 0.99;
		this.maxEffort = 8;
		this.startPopulationSize = 5 * n;
		this.nTor = 5;
		this.n = n;
	}

	/**
	 * Main method from which program starts to execute. Method use arguments
	 * form command line
	 * 
	 * @param args
	 *            arguments from command line
	 */
	public static void main(String[] args) {
		if (args.length != 1) {
			errorMsg();
		}
		int sizeOfVector = 0;
		try {
			sizeOfVector = Integer.parseInt(args[0]);

		} catch (NumberFormatException ex) {
			errorMsg();
		}

		GeneticAlgorithm genAlgh = new GeneticAlgorithm(sizeOfVector);
		genAlgh.run();
	}

	/**
	 * Method which display user how to use program
	 */
	private static void errorMsg() {
		System.out.println("Dear user, first argument is size of binary vector");

		System.exit(0);
	}

	public BitvectorSolution run() {
		ArrayList<BitvectorSolution> startPopulation = new ArrayList<>();

		for (int i = 0; i < startPopulationSize; i++) {

			BitvectorSolution temp = new BitvectorSolution(n, null, null, new Function(n), null);
			temp.randomize(new Random());
			temp.updateFitness();
			startPopulation.add(temp);
		}

		Tournament<BitvectorSolution> select = new Tournament(nTor);
		RandomSelection randSelct = new RandomSelection();
		Mutation mutation = new Mutation();
		CrossOverBit crossover = new CrossOverBit();
		double compFactor = comFactor;
		ArrayList<BitvectorSolution> newPopulation = new ArrayList<>();
		int populationSize = startPopulationSize;
		Random rand = new Random();
		int tries = 0;
		double effort = 0;

		do {
			ArrayList<BitvectorSolution> nTor1 = new ArrayList<>();
			for (int i = 0; i < nTor; i++) {
				nTor1.add(startPopulation.get(rand.nextInt(populationSize)));
			}
			BitvectorSolution parent1 = select
					.select(Arrays.copyOf(nTor1.toArray(), nTor1.size(), BitvectorSolution[].class));
			ArrayList<BitvectorSolution> nTor2 = new ArrayList<>();
			for (int i = 0; i < nTor; i++) {
				nTor2.add(startPopulation.get(rand.nextInt(populationSize)));
			}
			//BitvectorSolution parent2 = select
			//		.select(Arrays.copyOf(nTor2.toArray(), nTor2.size(), BitvectorSolution[].class));
			BitvectorSolution parent2 = startPopulation.get(rand.nextInt(startPopulation.size()));
			BitvectorSolution child = crossover.cross(parent1, parent2);
			child = mutation.mutation(child);
			child.updateFitness();
			if (child.fitness == 1.0) {
				System.out.println("The best at the end is " + child.fitness + " " + child.toString());
				return child;
			}
			if (child.fitness >= (Math.min(parent1.fitness, parent2.fitness)
					+ (1 - compFactor) * Math.abs(parent1.fitness - parent2.fitness))) {
				if (!newPopulation.contains(child)) {
					newPopulation.add(child);

				}
			} else {
				tries++;
			}

			compFactor *= alpha;

			effort = (newPopulation.size() + tries) / startPopulation.size();
			if (newPopulation.size() >= maxPopoluationSize) {
				startPopulation = new ArrayList<>(newPopulation);
				newPopulation = new ArrayList<BitvectorSolution>();
				populationSize = startPopulation.size();
				tries = 0;
				effort = 0;
				compFactor = comFactor;

				Collections.sort(startPopulation, new Comparator<BitvectorSolution>() {
					@Override
					public int compare(BitvectorSolution o1, BitvectorSolution o2) {
						if (o1.fitness > o2.fitness) {
							return -1;
						} else if (o1.fitness == o2.fitness) {
							return 0;
						}
						return 1;

					}
				});

				BitvectorSolution best = startPopulation.get(0);
				System.out.println("The best in new population " + best.fitness + " " + best.toString());

				continue;

			}
			if (effort >= maxEffort && newPopulation.size() >= minPopulationSize) {
				startPopulation = new ArrayList<>(newPopulation);
				newPopulation = new ArrayList<BitvectorSolution>();
				populationSize = startPopulation.size();
				tries = 0;
				effort = 0;
				compFactor = comFactor;

				Collections.sort(startPopulation, new Comparator<BitvectorSolution>() {
					@Override
					public int compare(BitvectorSolution o1, BitvectorSolution o2) {
						if (o1.fitness > o2.fitness) {
							return -1;
						} else if (o1.fitness == o2.fitness) {
							return 0;
						}
						return 1;

					}
				});

				BitvectorSolution best = startPopulation.get(0);
				System.out.println("The best in new population " + best.fitness + " " + best.toString());

				continue;
			}

		} while (effort <= maxEffort);

		Collections.sort(newPopulation, new Comparator<BitvectorSolution>() {
			@Override
			public int compare(BitvectorSolution o1, BitvectorSolution o2) {
				if (o1.fitness > o2.fitness) {
					return -1;
				} else if (o1.fitness == o2.fitness) {
					return 0;
				}
				return 1;

			}
		});

		BitvectorSolution best = newPopulation.get(0);
		System.out.println("The best at the end is " + best.fitness + " " + best.toString());
		return best;

	}
}
