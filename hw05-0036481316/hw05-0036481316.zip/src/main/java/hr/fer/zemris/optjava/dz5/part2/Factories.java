package hr.fer.zemris.optjava.dz5.part2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import hr.fer.zemris.optjava.dz5.part1.SingleObjectiveSolution;

/**
 * Class represent layout of factories in well-known locations.
 * Class extends {@link SingleObjectiveSolution}
 * 
 * @author Branko
 *
 */
public class Factories extends SingleObjectiveSolution{

	/**
	 * List contains layout of factories
	 */
	public ArrayList<Integer> solution = new ArrayList<>();
	/**
	 * Protected reference to {@linkplain Function}
	 */
	protected Function function;
	/**
	 * Number of factories
	 */
	private int n;
	
	/**
	 * Method for refreshing values of fitness
	 */
	public void updateFitness(){
		value = function.valueAt(this);
		fitness = value;
	}
	
	/**
	 * Public constructor accepts desire values.
	 * 
	 * @param n desire number of factories
	 */
	public Factories(int n, Function function){
		super(null, null, null, null);
		this.function = function;
		solution = new ArrayList<>();//(Arrays.asList(9-1,10-1,7-1,18-1,14-1,19-1,13-1,17-1,6-1,11-1,4-1,5-1,12-1,8-1,15-1,16-1,1-1,2-1,3-1));
		this.n = n;
		
		for(int i =0; i<n; i++){
			solution.add(i);
		}
		this.randomize();
		updateFitness();
		
	}
	
	/**
	 * Method shuffle factories by location
	 */
	public void randomize(){
		Collections.shuffle(solution);
		
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[ ");
		for(int i = 0, size = solution.size(); i< size; i++){
			sb.append(solution.get(i)+1);
			if(i != (size-1)){
				sb.append(", ");
			}
		}
		sb.append(" ]");
		return sb.toString();
	}
	
}
