package hr.fer.zemris.optjava.dz5.part2;

import java.util.Random;
/**
 * Class implements mutation of genetic algorithm
 * @author Branko
 *
 */
public class Mutation {

	/**
	 * Method mutates a unit.
	 * @param fact unit
	 * @return mutated unit
	 */
	public Factories mutation(Factories fact){
		Random rand = new Random();
		int index1 = rand.nextInt(fact.solution.size());
		int index2 = 0;
		do{
			index2 = rand.nextInt(fact.solution.size());
		}while(index1 == index2);
		int temp = fact.solution.get(index1);
		fact.solution.set(index1, fact.solution.get(index2));
		fact.solution.set(index2, temp);
		return fact;
	}
}
