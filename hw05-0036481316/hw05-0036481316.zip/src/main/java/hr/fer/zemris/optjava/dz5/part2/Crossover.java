package hr.fer.zemris.optjava.dz5.part2;

import java.util.ArrayList;

/**
 * Class implements crossover of genetic algorithm.
 * 
 * @author Branko
 *
 */
public class Crossover {

	/**
	 * Method implements crossover of two parents producing one child
	 * @param parent1 first parent
	 * @param parent2 second parent
	 * @return child
	 */
	public Factories cross(Factories parent1, Factories parent2){
		Factories child = new Factories(parent1.solution.size(), parent1.function);
		int selPoint = (int)(parent1.solution.size()/2);
		ArrayList<Integer> pieces = new ArrayList<>();
		for(int i = 0, size =parent1.solution.size(); i <size; i++ ){
			if(i<selPoint){
				child.solution.set(i, parent1.solution.get(i));
			}else{
				pieces.add(parent1.solution.get(i));
			}
		}
		for(int i = 0, size =parent2.solution.size(); i <size; i++ ){
			if(pieces.contains(parent2.solution.get(i))){
				child.solution.set(selPoint, parent2.solution.get(i));
				selPoint++;

			}
				
			
		}
		return child;
	}
}
