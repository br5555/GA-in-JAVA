package hr.fer.zemris.optjava.dz5.part1;

import java.util.Random;

/**
 * Class implements mutation of unit.
 * 
 * @author Branko
 *
 */
public class Mutation {

	/**
	 * Method implements mutation of unit.
	 * 
	 * @param t
	 *            unit
	 * @return mutated unit.
	 */
	public BitvectorSolution mutation(BitvectorSolution t) {
		Random rand = new Random();
		boolean change = false;
		BitvectorSolution temp = t.duplicate();
		for (int i = 0, limit = temp.bits.length; i < limit; i++) {
			if (rand.nextDouble() < 0.15) {
				temp.bits[i] = temp.bits[i] ^ true;
				change = true;
			}
		}
		if (!change) {
			int index = rand.nextInt(temp.bits.length);
			temp.bits[index] = temp.bits[index] ^ true;
		}
		temp.updateFitness();
		return temp;
	}
}
